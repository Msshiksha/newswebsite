# CNN-starter-code

In this Youtube video tutorial titled "How to make website like CNN using HTML & CSS", you will learn how to build a responsive CNN website with HTML5 and CSS3. 
I will go step by step in building CNN website. You'll learn how to layout easily using Flexbox.
Begginers tutorials for HTML and CSS.Improve your CSS skills with this latest tutorial.
We have added Starter code link below.



Invite/Hire me to your project in mind  : https://www.upwork.com/workwith/irvinemesa

You can download the Starter Code and learn by yourself.

Starter code link :https://github.com/DrMESAZIM/CNN-starter-code.git


Playlists links

Frontend Mentor Challenges :
https://www.youtube.com/watch?v=oWVQHorp8cM&list=PLJdBgzM3s56m1WhuJq8NYZkU1Ks4diqyM

CSS Animation :
https://www.youtube.com/watch?v=jMdsTCA-vi0&list=PLJdBgzM3s56mc3BNJMZx1JhRVIs8Iul6N

JavaScript Projects for Beginners:
https://www.youtube.com/watch?v=ecreGdCsrSM&list=PLJdBgzM3s56nThlOcZFxaGoE5bKV2LilC

Thank you.

#irvinemesa #html #websitedevelopment #newswebsite #programmer #programming 
#purecss  #css  #flexbox

A Flexbox is a new layout mode in CSS3. You can use the flexbox property
in building a real-time website that would save the developers a lot of effort. 
In this tutorial, we'll see how easy it is to layout and make 
the website responsive (render on mobile devices) using Flexbox.
